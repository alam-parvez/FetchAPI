

function getApiData()
{
    var request = new XMLHttpRequest();
    var cname = "bharat"


    var input = document.getElementById("cname")
    if(input)
    cname = input.value;


    request.open("get","https://restcountries.com/v3.1/name/"+cname)
    request.send();
    request.addEventListener("load",()=>{
        // console.log(request.responseText);

        var data = JSON.parse(request.responseText)
        data = data[0]
        console.log(data.name.official);
        console.log(data.capital);
        console.log(data.flags.svg);
        console.log(data.population);
        console.log(data.area);
        console.log(data.region);
        console.log(data.subregion);
        console.log(data.continents);
        console.log(data.borders);
        console.log(data.timezones);
        console.log(data.independent);
        console.log(data.unMember);
        console.log(data.landlocked);
        console.log(data.maps.googleMaps);

        document.getElementById("name").innerHTML = data.name.official
        document.getElementById("capital").innerHTML = data.capital
        document.getElementById("flags").src = data.flags.svg
        document.getElementById("population").innerHTML = data.population
        document.getElementById("area").innerHTML = data.area
        document.getElementById("region").innerHTML = data.region
        document.getElementById("subregion").innerHTML = data.subregion
        document.getElementById("continents").innerHTML = data.continents
        document.getElementById("borders").innerHTML = data.borders
        document.getElementById("timezones").innerHTML = data.timezones
        document.getElementById("independent").innerHTML = data.independent
        document.getElementById("unMember").innerHTML = data.unMember
        document.getElementById("landlocked").innerHTML = data.landlocked
        document.getElementById("Maps.googleMaps").href = data.maps.googleMaps
        
        
    })
}
getApiData()
